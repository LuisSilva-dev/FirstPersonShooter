﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletGranade : MonoBehaviour
{
    private float frame;
    private float vel;
    public const float VEL = 0.0005f;
    public const float G = -0.001f;
    public const float rotationVel = -0.5f;
    // Start is called before the first frame update
    void Start()
    {
        vel = 0.2f;
        frame = 0;
        gameObject.AddComponent<Rigidbody>();
        gameObject.GetComponent<Renderer>().material = Resources.Load("Materials/GranadeBullet", typeof(Material)) as Material;
        transform.localScale = new Vector3(0.08f, 0.08f, 0.08f);
    }

    // Update is called once per frame
    void Update()
    {
        frame += G;
        vel -= VEL;
        if (Mathf.Round(transform.rotation.eulerAngles.x) != 90)
        {
            transform.position = transform.position + transform.forward * vel + transform.up * frame;
            transform.Rotate(Vector3.left * rotationVel);
        }
        else
        {
            transform.position = transform.position + transform.up * frame;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("SUP");
    }
}
